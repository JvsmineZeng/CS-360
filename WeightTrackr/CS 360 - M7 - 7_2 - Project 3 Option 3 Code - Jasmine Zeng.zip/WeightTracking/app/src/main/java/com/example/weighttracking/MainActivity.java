package com.example.weighttracking;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MainActivity extends AppCompatActivity {

    // Initialize WeightTrackr database
    AppDatabase db;

    // Create database room of users
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "users").build();
    }

    // Register account
    public void RegisterClick(View v){
        EditText usernameText = (EditText) findViewById(R.id.username);
        EditText passwordText = (EditText) findViewById(R.id.password);
        String nameTextValue = usernameText.getText().toString();
        String passwordTextValue = passwordText.getText().toString();
        if(!checkLogin(nameTextValue, passwordTextValue)){
            createUser(nameTextValue, passwordTextValue);
        }
    }

    // Login
    public void LoginClick(View v){
        EditText usernameText = (EditText) findViewById(R.id.username);
        EditText passwordText = (EditText) findViewById(R.id.password);
        String nameTextValue = usernameText.getText().toString();
        String passwordTextValue = passwordText.getText().toString();
        if(checkLogin(nameTextValue, passwordTextValue)){
            setContentView(R.layout.activity_main);
        }
    }

    // Validate login
    private boolean checkLogin(String username, String password){
        UserDao userDao = db.userDao();
        User user = userDao.findByName(username, password);
        return user != null;
    }

    // Create new user
    private void createUser(String username, String password){
        UserDao userDao = db.userDao();
        User user = new User();
        user.userName = username;
        user.password = password;
        userDao.insertAll(user);
    }
}