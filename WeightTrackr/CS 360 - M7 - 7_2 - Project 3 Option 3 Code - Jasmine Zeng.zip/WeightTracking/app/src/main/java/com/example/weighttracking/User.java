package com.example.weighttracking;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// User object
@Entity
public class User {

    // Initialize user ID number
    @PrimaryKey
    public int uid;

    // Initialize username string
    @ColumnInfo(name = "username")
    public String userName;

    // Initialize password string
    @ColumnInfo(name = "password")
    public String password;

    // Initialize phone number
    @ColumnInfo(name = "phone")
    public String phone;
}