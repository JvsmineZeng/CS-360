package com.example.weighttracking;

import androidx.room.Database;
import androidx.room.RoomDatabase;

// WeightTrackr database
@Database(entities = {User.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    // Initialize userDao create, store, and delete features
    public abstract UserDao userDao();
}