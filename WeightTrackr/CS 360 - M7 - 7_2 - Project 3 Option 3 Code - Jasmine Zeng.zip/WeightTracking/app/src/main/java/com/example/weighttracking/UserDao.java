package com.example.weighttracking;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


// Manages WeightTrackr users
@Dao
public interface UserDao {

    // List of users
    @Query("SELECT * FROM user")
    List<User> getAll();

    // List of users by ID
    @Query("SELECT * FROM user WHERE uid IN (:userIds)")
    List<User> loadAllByIds(int[] userIds);

    // User's first and last name
    @Query("SELECT * FROM user WHERE username LIKE :first AND " +
            "password LIKE :last LIMIT 1")
    User findByName(String first, String last);

    // Stream all user data into database
    @Insert
    void insertAll(User... users);

    // Delete user
    @Delete
    void delete(User user);
}
