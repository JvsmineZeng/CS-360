package com.example.weighttracking;

import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class PermissionsActivity extends AppCompatActivity {

    // Register phone number for SMS
    public void RegisterSMS(View v){
        int phoneNumber = (R.id.enterPhoneNumber);
        String phoneNumberValue = Integer.toString(phoneNumber);
        if(checkSMS(phoneNumberValue)){
            System.out.println("Thank you! You will receive a text confirmation soon.");
        }
    }

    // Validate phone number
    private boolean checkSMS(String number) {
        return true;
    }
}
